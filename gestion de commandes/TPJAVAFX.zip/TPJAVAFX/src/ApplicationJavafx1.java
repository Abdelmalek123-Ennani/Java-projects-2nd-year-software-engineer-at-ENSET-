import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class ApplicationJavafx1 extends Application {

    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) throws Exception {
        BorderPane root=new BorderPane();
        Label labelNom=new Label("Nom :");
        TextField textFieldNom=new TextField();
        Button buttonAdd=new Button("Ajouter");
        Button buttonDel=new Button("Supprimer");
        HBox hBox=new HBox();
        hBox.getChildren().addAll(labelNom,textFieldNom,buttonAdd,buttonDel);
        root.setTop(hBox);
        hBox.setSpacing(10);
        hBox.setPadding(new Insets(10,10,10,10));
        ListView<String> listView=new ListView<>();
        ObservableList<String> observableList= FXCollections.observableArrayList();
        listView.setItems(observableList);

        root.setCenter(listView);
        Scene scene=new Scene(root,400,400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Voitures");
        primaryStage.show();
        buttonAdd.setOnAction(event ->{
            String nom=textFieldNom.getText();
            if(nom.isEmpty()){
                Alert alert=new Alert(Alert.AlertType.WARNING);
                alert.setContentText("Veuillez saisir un nom !!!");
                alert.show();
            }else {
                observableList.add(nom);
                textFieldNom.setText("");
            }
        } );
        buttonDel.setOnAction(event -> {
            int index=listView.getSelectionModel().getSelectedIndex();
            if(index>=0){
                observableList.remove(index);
            }else{
                Alert alert=new Alert(Alert.AlertType.WARNING);
                alert.setContentText("Veuillez sélectionner un élément !!");
                alert.show();
            }
        });
    }
}
