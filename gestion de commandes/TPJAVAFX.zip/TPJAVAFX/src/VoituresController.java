import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class VoituresController implements Initializable {
 @FXML
 private TextField textNom;
 @FXML
 private ListView<String> listView;
 private ObservableList<String> observableList= FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        listView.setItems(observableList);
        observableList.add("FIAT");
        observableList.add("CITROEN");
    }
    @FXML
    private void addVoiture(){
        String nom=textNom.getText();
        if(nom.isEmpty()){
            Alert alert=new Alert(Alert.AlertType.WARNING);
            alert.setContentText("Veuillez saisir un nom !!!");
            alert.show();
        }else{
            observableList.add(nom);
            textNom.clear();
        }
    }
    @FXML
    private void deleteVoiture(){
        int index=listView.getSelectionModel().getSelectedIndex();
        if(index>=0){
            observableList.remove(index);
        }else{
            Alert alert=new Alert(Alert.AlertType.WARNING);
            alert.setContentText("Veuillez sélectionner un élément !!");
            alert.show();
        }
    }
}
